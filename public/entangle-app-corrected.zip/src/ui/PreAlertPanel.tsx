import React from 'react';
import { AlertTriangle, Check } from 'lucide-react';
import { useWorldStore } from '../state/store.ts';

export const PreAlertPanel: React.FC = () => {
  const preAlerts = useWorldStore(state => state.preAlerts);
  const acknowledgePreAlert = useWorldStore(state => state.acknowledgePreAlert);
  const pending = Object.values(preAlerts)
    .filter(alert => !alert.acknowledged)
    .sort((a, b) => b.createdAt - a.createdAt);

  if (pending.length === 0) return null;

  return (
    <section
      className="rounded-2xl border border-[#DDA06A] bg-[#FFF4E4] p-4 shadow-xs"
      aria-label="Correlated-neighbour pre-alerts requiring operator acknowledgement"
      aria-live="polite"
    >
      <div className="flex items-start gap-2">
        <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-[#B0623A]" />
        <div className="min-w-0 flex-1">
          <h2 className="font-heading text-sm font-bold text-[#3A2E26]">
            Correlated-neighbour pre-alerts · {pending.length} need acknowledgement
          </h2>
          <p className="mt-1 text-[10px] leading-relaxed text-[#7A6A5A]">
            Conditional seeded simulation only. Correlation is not causation; review this advisory before acknowledging.
          </p>
          <ul className="mt-3 space-y-2">
            {pending.map(alert => (
              <li key={alert.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-[#E8D0B5] bg-[#FFFDF8] p-2.5">
                <p className="min-w-0 flex-1 text-xs leading-relaxed text-[#3A2E26]">
                  <strong>{alert.triggerLabel} worsened.</strong> {alert.neighborLabel}'s simulated reach is estimated to move from{' '}
                  <strong>{Math.round(alert.probabilityBefore * 100)}%</strong> to{' '}
                  <strong>{Math.round(alert.probabilityAfter * 100)}%</strong> if {alert.triggerLabel} is missed.
                  <span className="ml-1 font-mono text-[9px] text-[#7A6A5A]">
                    MI {alert.mutualInformationBits.toFixed(3)} bit · phi {alert.phi.toFixed(2)}
                  </span>
                </p>
                <button
                  type="button"
                  onClick={() => acknowledgePreAlert(alert.id)}
                  className="inline-flex shrink-0 items-center gap-1 rounded-lg bg-[#4F7C82] px-2.5 py-1.5 text-[10px] font-bold text-white hover:bg-[#3D666C]"
                >
                  <Check className="h-3 w-3" />
                  Acknowledge
                </button>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
};
