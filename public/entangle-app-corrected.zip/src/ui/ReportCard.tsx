/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * ReportCard: Displays raw citizen and field reports with live CredibilityMeter,
 * language badges, people-at-risk indicators, and merge/unverified status.
 */

import React, { useMemo, useState } from 'react';
import { Clock, Users, Globe, ShieldAlert, GitMerge, Hourglass } from 'lucide-react';
import { estimateWaitDecision } from '../quantum/waitDecision.ts';
import { reportFreshness, reportHalfLifeMinutes } from '../quantum/interference.ts';
import { Report } from '../state/types.ts';
import { useWorldStore } from '../state/store.ts';
import { CredibilityMeter } from './CredibilityMeter.tsx';

const ShouldWeWaitAdvisor: React.FC<{ report: Report }> = ({ report }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [waitMinutes, setWaitMinutes] = useState(15);
  const incidents = useWorldStore(state => state.incidents);
  const volunteers = useWorldStore(state => state.volunteers);
  const resources = useWorldStore(state => state.resources);
  const reports = useWorldStore(state => state.reports);
  const areas = useWorldStore(state => state.areas);
  const context = useWorldStore(state => state.context);
  const candidatePlans = useWorldStore(state => state.candidatePlans);
  const world = useMemo(() => ({
    incidents,
    volunteers,
    resources,
    reports,
    areas,
    context: { rainfallMmHr: context.rainfallMmHr },
  }), [incidents, volunteers, resources, reports, areas, context.rainfallMmHr]);
  const currentPlan = candidatePlans.find(plan => plan.status === 'approved' || plan.status === 'executed')
    || candidatePlans.find(plan => plan.status === 'candidate' && plan.strategy === 'entangled_optimal')
    || candidatePlans.find(plan => plan.status === 'candidate');
  const assignments = currentPlan?.assignments || [];
  const estimate = useMemo(
    () => isOpen ? estimateWaitDecision(report, world, assignments, waitMinutes) : null,
    [isOpen, report, world, assignments, waitMinutes]
  );

  return (
    <section className="mt-3 rounded-xl border border-[#D8CCB5] bg-[#FAF6EE] p-3">
      <button
        type="button"
        aria-expanded={isOpen}
        onClick={() => setIsOpen(value => !value)}
        className="flex w-full items-center justify-between gap-2 text-left text-xs font-bold text-[#3A2E26]"
      >
        <span className="inline-flex items-center gap-1.5"><Hourglass className="h-3.5 w-3.5 text-[#B0623A]" />Should we wait? <span className="font-mono text-[9px] uppercase text-[#7A6A5A]">estimate · advisory</span></span>
        <span aria-hidden="true">{isOpen ? '−' : '+'}</span>
      </button>
      {isOpen && estimate && (
        <div className="mt-3 space-y-2.5">
          <label htmlFor={`wait-minutes-${report.id}`} className="flex items-center justify-between gap-2 text-[10px] font-mono text-[#7A6A5A]">
            <span>Wait for second source</span>
            <strong className="text-[#3A2E26]">{waitMinutes} min</strong>
          </label>
          <input
            id={`wait-minutes-${report.id}`}
            type="range"
            min="5"
            max="60"
            step="5"
            value={waitMinutes}
            onChange={event => setWaitMinutes(Number(event.target.value))}
            className="w-full accent-[#4F7C82]"
          />
          <div className="rounded-lg border border-[#E4D9C5] bg-[#FFFDF8] p-2.5">
            <p className="text-xs font-bold text-[#3A2E26]">
              {estimate.recommendation === 'no-responder'
                ? 'No available responder for this comparison'
                : estimate.recommendation === 'act-now'
                ? 'Estimate favors acting now'
                : `Estimate favors waiting ${estimate.waitMinutes} minutes`}
            </p>
            {estimate.hasAvailableResponder && (
              <>
                <p className="mt-1 text-[10px] leading-relaxed text-[#5A5146]">
                  Interference credibility: {Math.round(estimate.reportCredibility * 100)}% · simulated reach if now: {Math.round(estimate.immediateReachProbability * 100)}% · after delay: {Math.round(estimate.delayedReachProbability * 100)}%.
                </p>
                <p className="mt-1 font-mono text-[10px] text-[#3A2E26]">
                  Net people-equivalent: now {estimate.expectedPeopleIfActNow.toFixed(1)} · wait {estimate.expectedPeopleIfWaiting.toFixed(1)}
                </p>
                <p className="mt-1 text-[10px] text-[#7A6A5A]">
                  Break-even credibility: {estimate.breakEvenCredibility === null ? 'not reached in 0–100%' : `${Math.round(estimate.breakEvenCredibility * 100)}%`} · expected wasted-dispatch cost {estimate.expectedWastedDispatchCost.toFixed(1)} people-equivalent · crew held about {estimate.crewTimeHeldMinutes} min{estimate.boatHeld ? ' · a boat is reserved in this scenario' : ''}.
                </p>
              </>
            )}
          </div>
          <p className="text-[9px] leading-relaxed text-[#7A6A5A]">
            Advisory simulation only; no dispatch is sent. The second-source arrival prior assumes 1 independent source per 30 minutes. Interference credibility is an uncalibrated ranking signal, not a forecast; unverified reports remain blocked by the existing approval gate. {estimate.simulatedTrials} seeded worlds.
          </p>
        </div>
      )}
    </section>
  );
};

interface ReportCardProps {
  report: Report;
  className?: string;
}

export const ReportCard: React.FC<ReportCardProps> = ({ report, className = '' }) => {
  const formatTime = (ts: number) => {
    const diff = Math.round((Date.now() - ts) / 60000);
    if (diff <= 1) return 'Just now';
    if (diff < 60) return `${diff}m ago`;
    return `${Math.round(diff / 60)}h ago`;
  };

  const isUnverified = report.isUnverified || (report.credibility !== undefined && report.credibility < 0.35);
  const freshness = reportFreshness(report);
  const halfLife = reportHalfLifeMinutes(report);

  return (
    <div
      className={`p-3.5 rounded-2xl bg-[#FFFDF8] border transition-all ${
        isUnverified
          ? 'border-[#E8BCB5] bg-[#FFF8F6]'
          : 'border-[#E4D9C5] hover:border-[#7A6A5A]/50'
      } ${className}`}
    >
      {/* Header row */}
      <div className="flex items-center justify-between gap-2 mb-2 flex-wrap text-xs font-mono">
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="font-bold text-[#3A2E26] uppercase px-2 py-0.5 rounded-md bg-[#E4D9C5]/60 text-[10.5px]">
            {report.area.toUpperCase()}
          </span>

          <span className="text-[10px] text-[#7A6A5A] px-1.5 py-0.5 rounded bg-[#FAF6EE] border border-[#E4D9C5]">
            Source: {report.source}
          </span>

          <span className="text-[10px] font-bold text-[#4F7C82] flex items-center gap-1">
            <Globe className="w-2.5 h-2.5" />
            {report.language.toUpperCase()}
          </span>

          {report.mergedInto && (
            <span className="text-[10px] text-[#5F7A61] flex items-center gap-1 font-semibold px-2 py-0.5 rounded-full bg-[#E3EDDF]">
              <GitMerge className="w-2.5 h-2.5" />
              Merged into #{report.mergedInto}
            </span>
          )}
        </div>

        <div className="flex items-center gap-1 text-[11px] text-[#7A6A5A]">
          <Clock className="w-3 h-3" />
          <span>{formatTime(report.ts)}</span>
        </div>
      </div>

      {/* Original report and its English translation */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-2.5">
        <div className="min-w-0">
          <span className="block text-[10px] font-mono font-bold uppercase text-[#7A6A5A] mb-1">
            Original ({report.language.toUpperCase()})
          </span>
          <p lang={report.language} className="h-full text-xs text-[#3A2E26] leading-relaxed italic bg-[#FAF6EE]/80 p-2.5 rounded-xl border border-[#E4D9C5]/50">
            &ldquo;{report.text}&rdquo;
          </p>
        </div>
        <div className="min-w-0">
          <span className="block text-[10px] font-mono font-bold uppercase text-[#7A6A5A] mb-1">
            English translation
          </span>
          <p lang="en" className="h-full text-xs text-[#3A2E26] leading-relaxed bg-[#FAF6EE]/80 p-2.5 rounded-xl border border-[#E4D9C5]/50">
            {report.englishTranslation
              ? `“${report.englishTranslation}”`
              : report.translationStatus === 'pending'
                ? 'Translation pending…'
                : report.translationStatus === 'unavailable'
                  ? 'Translation unavailable.'
                  : report.language === 'en'
                    ? `“${report.text}”`
                    : 'English translation not available.'}
          </p>
        </div>
      </div>

      {/* Flags & people at risk */}
      <div className="flex items-center gap-2 flex-wrap text-[10.5px] font-mono text-[#7A6A5A] mb-2.5">
        {report.transcriptionConfidence !== undefined && (
          <span className={`rounded-full border px-2 py-0.5 ${report.humanReviewedTranscript ? 'border-[#5F7A61] bg-[#E3EDDF] text-[#3D5939]' : 'border-[#D8CCB5] bg-[#FAF6EE]'}`}>
            Transcript confidence {Math.round(report.transcriptionConfidence * 100)}%{report.humanReviewedTranscript ? ' · human reviewed' : ''}
          </span>
        )}
        {report.peopleAtRisk && (
          <span className="flex items-center gap-1 text-[#3A2E26] font-bold px-2 py-0.5 rounded bg-[#FAF6EE] border border-[#E4D9C5]">
            <Users className="w-3 h-3 text-[#B0623A]" />
            {report.peopleAtRisk} at risk
          </span>
        )}

        {report.flags?.map(flag => (
          <span
            key={flag}
            className="px-2 py-0.5 rounded-full bg-[#FAF6EE] text-[#7A6A5A] border border-[#E4D9C5] text-[10px]"
          >
            #{flag}
          </span>
        ))}
      </div>

      {/* Credibility Meter Bar */}
      <div className="pt-2 border-t border-[#E4D9C5]/60">
        <CredibilityMeter
          score={report.credibility ?? report.credibilityScore ?? 0.50}
          reasons={report.credibilityReasons || (report.credibilityExplanation ? [report.credibilityExplanation] : [])}
          isUnverified={isUnverified}
        />
      </div>
      <div className="mt-2" aria-label={`Evidence freshness ${Math.round(freshness * 100)} percent`}>
        <div className="mb-1 flex justify-between text-[9px] font-mono text-[#7A6A5A]">
          <span>Evidence coherence · {halfLife} min half-life</span>
          <span>{Math.round(freshness * 100)}%</span>
        </div>
        <div className="h-1.5 overflow-hidden rounded-full bg-[#E4D9C5]">
          <div className="h-full rounded-full bg-[#4F7C82] transition-[width]" style={{ width: `${freshness * 100}%` }} />
        </div>
      </div>
      {isUnverified && <ShouldWeWaitAdvisor report={report} />}
    </div>
  );
};
