import React, { useMemo, useState } from 'react';
import { annealDispatch, limitResponders } from '../quantum/anneal.ts';
import {
  collapse,
  entangledMonteCarlo,
  incidentPoint,
  peopleAtRisk,
  type EntangledEdge,
  type QWorld,
} from '../quantum/entangledSim.ts';
import { interfere } from '../quantum/interference.ts';
import { analyzeWardEquity } from '../quantum/equity.ts';
import { useWorldStore } from '../state/store.ts';
import type { Area, Incident, Report } from '../state/types.ts';
import { THEME_TOKENS } from '../theme/tokens.ts';

type Observation = 'reached' | 'missed';
type ObservedOutcomes = Record<string, Observation>;

const colors = THEME_TOKENS.colors;

function asRecord<T extends { id: string }>(items: T[]): Record<string, T> {
  return Object.fromEntries(items.map(item => [item.id, item]));
}

function incidentLabel(incident: Incident, areas: Record<string, Area>): string {
  return areas[incident.area]?.name || incident.area;
}

function percentage(value: number): string {
  return `${(value * 100).toFixed(0)}%`;
}

function fieldLayout(incidents: Incident[], areas: Record<string, Area>) {
  const points = incidents.map(incident => ({
    incident,
    point: incidentPoint(incident, { areas }),
  }));
  const minX = Math.min(...points.map(({ point }) => point.x));
  const maxX = Math.max(...points.map(({ point }) => point.x));
  const minY = Math.min(...points.map(({ point }) => point.y));
  const maxY = Math.max(...points.map(({ point }) => point.y));
  const width = Math.max(160, maxX - minX + 120);
  const height = Math.max(160, maxY - minY + 120);

  return {
    width,
    height,
    nodes: points.map(({ incident, point }) => ({
      incident,
      x: point.x - minX + 60,
      y: point.y - minY + 60,
    })),
  };
}

export const QuantumLab: React.FC = () => {
  const incidents = useWorldStore(state => state.incidents);
  const volunteers = useWorldStore(state => state.volunteers);
  const resources = useWorldStore(state => state.resources);
  const reports = useWorldStore(state => state.reports);
  const areas = useWorldStore(state => state.areas);

  const [rainfallMmHr, setRainfallMmHr] = useState(75);
  const [responders, setResponders] = useState(12);
  const [observed, setObserved] = useState<ObservedOutcomes>({});
  const [interferenceId, setInterferenceId] = useState('');

  const openIncidents = useMemo(
    () => Object.values(incidents).filter(incident => incident.status !== 'resolved'),
    [incidents]
  );
  const volunteerCount = Object.keys(volunteers).length;
  const responderMin = Math.min(4, volunteerCount);
  const responderCount = Math.max(responderMin, Math.min(responders, volunteerCount));

  const analysis = useMemo(() => {
    if (openIncidents.length === 0) return null;

    const world: QWorld = limitResponders({
      incidents: asRecord(openIncidents),
      volunteers,
      resources,
      reports,
      areas,
      context: { rainfallMmHr },
    }, responderCount, 3);
    const incidentIds = openIncidents.map(incident => incident.id);
    const annealing = annealDispatch(world, incidentIds, { seed: 7 });

    return {
      world,
      annealing,
      oneEachSim: entangledMonteCarlo(annealing.oneEach.assignments, world, 600, 42),
      greedySim: entangledMonteCarlo(annealing.greedy.assignments, world, 600, 42),
      annealedSim: entangledMonteCarlo(annealing.annealed.assignments, world, 600, 42),
    };
  }, [openIncidents, volunteers, resources, reports, areas, rainfallMmHr, responderCount]);

  const observedAsBooleans = useMemo(
    () => Object.fromEntries(Object.entries(observed).map(([id, value]) => [id, value === 'reached'])),
    [observed]
  );
  const collapsed = useMemo(
    () => analysis ? collapse(analysis.annealedSim, observedAsBooleans) : null,
    [analysis, observedAsBooleans]
  );

  const selectedIncident = openIncidents.find(incident => incident.id === interferenceId)
    || openIncidents[0];
  const selectedReports = useMemo(
    () => selectedIncident
      ? selectedIncident.reportIds.map(id => reports[id]).filter((report): report is Report => Boolean(report))
      : [],
    [selectedIncident?.reportIds, reports]
  );
  const interference = useMemo(() => interfere(selectedReports), [selectedReports]);
  const selectedIncidentId = selectedIncident?.id;

  const cycleObservation = (incidentId: string) => {
    setObserved(current => {
      if (!current[incidentId]) return { ...current, [incidentId]: 'reached' };
      if (current[incidentId] === 'reached') return { ...current, [incidentId]: 'missed' };
      const next = { ...current };
      delete next[incidentId];
      return next;
    });
  };

  const field = openIncidents.length > 0
    ? fieldLayout(openIncidents, areas)
    : { width: 160, height: 160, nodes: [] };
  const fieldNodes = new Map(field.nodes.map(node => [node.incident.id, node]));
  const fieldEdges = (analysis?.annealedSim.edges || [])
    .filter(edge => edge.mutualInformationBits >= 0.005)
    .slice(0, 8);
  const strongestEdge = Math.max(0, ...fieldEdges.map(edge => edge.mutualInformationBits));
  const observations = Object.entries(observed).filter(([id]) => openIncidents.some(incident => incident.id === id));
  const observationLabel = observations.length
    ? observations.map(([id, outcome]) => {
      const incident = openIncidents.find(item => item.id === id);
      return `${incident ? incidentLabel(incident, areas) : id} ${outcome}`;
    }).join(', ')
    : 'no observations';

  const annealed = analysis?.annealing;
  const assignmentRows = annealed ? [
    { label: 'One crew per incident (current agent)', solution: annealed.oneEach, simulation: analysis.oneEachSim },
    { label: 'Marginal-gain greedy', solution: annealed.greedy, simulation: analysis.greedySim },
    { label: 'Annealed (entanglement-aware)', solution: annealed.annealed, simulation: analysis.annealedSim },
  ] : [];
  const trace = annealed?.trace || [];
  const traceMin = Math.min(...trace);
  const traceMax = Math.max(...trace);
  const tracePoints = trace.map((energy, index) => {
    const x = trace.length <= 1 ? 150 : 8 + (index / (trace.length - 1)) * 284;
    const y = traceMax === traceMin ? 35 : 62 - ((energy - traceMin) / (traceMax - traceMin)) * 54;
    return `${x},${y}`;
  }).join(' ');

  const phasorTotal = interference.terms.reduce((sum, term) => sum + term.amplitude, 0);
  const phasorScale = phasorTotal > 0 ? 150 / phasorTotal : 0;
  const phasorHeight = Math.max(100, 34 * interference.terms.length + 46);
  const resultantX = 180 + interference.resultant.re * phasorScale;
  const entanglementIndex = analysis?.annealedSim.edges.reduce(
    (sum, edge) => sum + edge.mutualInformationBits,
    0
  ) || 0;
  const equity = useMemo(
    () => analysis && annealed
      ? analyzeWardEquity(analysis.world, annealed.annealed.assignments, analysis.annealedSim)
      : null,
    [analysis, annealed]
  );

  return (
    <div className="space-y-4">
      <section className="rounded-2xl border border-[#E4D9C5] bg-[#FFFDF8] p-4 shadow-[0_1px_2px_rgba(58,46,38,0.06)] sm:p-5">
        <div className="flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between">
          <div className="max-w-2xl">
            <p className="font-mono text-[10px] font-bold uppercase tracking-widest text-[#4F7C82]">Operator research panel</p>
            <h2 className="mt-1 font-heading text-xl font-bold text-[#3A2E26]">Quantum Lab</h2>
            <p className="mt-2 text-xs leading-relaxed text-[#7A6A5A]">
              Quantum-inspired, runs on a normal computer. No quantum hardware, no speed-up claimed. Seeded simulations on demonstration data, relative scores not forecasts.
            </p>
          </div>
          <div className="grid w-full gap-4 sm:grid-cols-2 xl:max-w-2xl">
            <label className="space-y-2 text-xs">
              <span className="flex items-center justify-between gap-2 font-semibold text-[#3A2E26]">
                <span>Rainfall stress</span>
                <span className="font-mono text-[#4F7C82]">{rainfallMmHr} mm/hr</span>
              </span>
              <input
                type="range"
                min={25}
                max={150}
                step={5}
                value={rainfallMmHr}
                onChange={event => setRainfallMmHr(Number(event.currentTarget.value))}
                aria-label="Rainfall stress in millimeters per hour"
                className="w-full accent-[#4F7C82]"
              />
              <span className="flex justify-between font-mono text-[10px] text-[#7A6A5A]"><span>25</span><span>150 mm/hr</span></span>
            </label>
            <label className="space-y-2 text-xs">
              <span className="flex items-center justify-between gap-2 font-semibold text-[#3A2E26]">
                <span>Responders</span>
                <span className="font-mono text-[#4F7C82]">{responderCount} of {volunteerCount}</span>
              </span>
              <input
                type="range"
                min={responderMin}
                max={volunteerCount}
                step={1}
                value={responderCount}
                disabled={volunteerCount === 0}
                onChange={event => setResponders(Number(event.currentTarget.value))}
                aria-label="Responders included in the simulation"
                className="w-full accent-[#4F7C82] disabled:opacity-40"
              />
              <span className="flex justify-between font-mono text-[10px] text-[#7A6A5A]"><span>{responderMin}</span><span>{volunteerCount} volunteers</span></span>
            </label>
            {analysis && (
              <div className="sm:col-span-2 flex flex-wrap items-center justify-between gap-2 rounded-xl border border-[#4F7C82]/25 bg-[#D7E3E5]/30 px-3 py-2">
                <span className="text-[10px] font-mono font-bold uppercase text-[#4F7C82]">Entanglement index · sum of pairwise MI</span>
                <span className="font-mono text-sm font-bold text-[#3A2E26]">{entanglementIndex.toFixed(3)} bit</span>
                <span className="w-full text-[9px] leading-relaxed text-[#7A6A5A]">
                  Correlated heat, power-cut and hospital-capacity stress is simulated from the heat index; this classical index is not a forecast.
                </span>
              </div>
            )}
          </div>
        </div>
      </section>

      {openIncidents.length === 0 || !analysis || !collapsed || !annealed ? (
        <div className="rounded-2xl border border-dashed border-[#D8CCB5] bg-[#FFFDF8] px-5 py-12 text-center">
          <h3 className="font-heading text-lg font-bold text-[#3A2E26]">No open incidents to simulate</h3>
          <p className="mx-auto mt-2 max-w-xl text-sm leading-relaxed text-[#7A6A5A]">
            Run the scenario or inject a report to create an incident. The Quantum Lab will then compare seeded, advisory-only simulations.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 items-start gap-4 2xl:grid-cols-3">
          <section className="min-w-0 rounded-2xl border border-[#E4D9C5] bg-[#FFFDF8] p-4 shadow-[0_1px_2px_rgba(58,46,38,0.06)]">
            <div className="mb-3">
              <h3 className="font-heading text-base font-bold text-[#3A2E26]">Entangled risk field</h3>
              <p className="mt-1 text-[11px] leading-relaxed text-[#7A6A5A]">Measured pairwise dependencies across 600 seeded worlds. Select a node to condition the annealed simulation.</p>
            </div>
            <div className="grid grid-cols-1 gap-3 2xl:grid-cols-[minmax(0,1.25fr)_minmax(0,0.9fr)]">
              <svg
                viewBox={`0 0 ${field.width} ${field.height}`}
                role="img"
                aria-label="Entangled risk field showing incident reach probabilities and measured dependencies"
                className="h-[360px] w-full rounded-xl border border-[#E4D9C5] bg-[#FAF6EE]"
                preserveAspectRatio="xMidYMid meet"
              >
                {fieldEdges.map((edge: EntangledEdge) => {
                  const a = fieldNodes.get(edge.a);
                  const b = fieldNodes.get(edge.b);
                  if (!a || !b) return null;
                  const midpointX = (a.x + b.x) / 2;
                  const midpointY = (a.y + b.y) / 2;
                  return (
                    <g key={`${edge.a}-${edge.b}`}>
                      <line
                        x1={a.x}
                        y1={a.y}
                        x2={b.x}
                        y2={b.y}
                        stroke={edge.phi >= 0 ? colors.agent : colors.clay}
                        strokeWidth={1.5 + 7 * edge.mutualInformationBits / strongestEdge}
                        opacity="0.72"
                      />
                      <text
                        x={midpointX}
                        y={midpointY - 5}
                        textAnchor="middle"
                        fontSize="9"
                        fontFamily={THEME_TOKENS.fonts.mono}
                        fill={colors.ink}
                        stroke={colors.surface}
                        strokeWidth="3"
                        paintOrder="stroke"
                      >
                        {edge.mutualInformationBits.toFixed(2)} bit
                      </text>
                    </g>
                  );
                })}
                {field.nodes.map(({ incident, x, y }) => {
                  const people = peopleAtRisk(incident, reports);
                  const radius = 14 + Math.min(14, 2 * Math.sqrt(people));
                  const probability = collapsed.probabilities[incident.id] ?? 0;
                  const ringRadius = radius + 5;
                  const circumference = 2 * Math.PI * ringRadius;
                  const ringColor = probability > 0.66
                    ? colors.primary
                    : probability > 0.33
                    ? colors.severity.high.base
                    : colors.kill;
                  const observation = observed[incident.id];
                  const fill = observation === 'reached'
                    ? '#DDEBDD'
                    : observation === 'missed'
                    ? '#F6DDD6'
                    : colors.surface;
                  return (
                    <g
                      key={incident.id}
                      role="button"
                      tabIndex={0}
                      aria-pressed={Boolean(observation)}
                      aria-label={`${incidentLabel(incident, areas)}, ${incident.id}, ${percentage(probability)} conditioned reach probability, currently ${observation || 'unobserved'}. Press Enter or Space to cycle unobserved, reached, and missed.`}
                      onClick={() => cycleObservation(incident.id)}
                      onKeyDown={event => {
                        if (event.key === 'Enter' || event.key === ' ') {
                          event.preventDefault();
                          cycleObservation(incident.id);
                        }
                      }}
                      className="cursor-pointer outline-none focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#4F7C82]"
                    >
                      <title>{`${incident.summary}: ${percentage(probability)} reach probability`}</title>
                      <circle cx={x} cy={y} r={ringRadius} fill="none" stroke={colors.border} strokeWidth="4" />
                      <circle
                        cx={x}
                        cy={y}
                        r={ringRadius}
                        fill="none"
                        stroke={ringColor}
                        strokeWidth="4"
                        strokeDasharray={`${circumference * probability} ${circumference}`}
                        strokeLinecap="round"
                        transform={`rotate(-90 ${x} ${y})`}
                      />
                      <circle cx={x} cy={y} r={radius} fill={fill} stroke={colors.inkMuted} strokeWidth="1.25" />
                      <text x={x} y={y + 3.5} textAnchor="middle" fontSize="11" fontWeight="700" fill={colors.ink}>
                        {percentage(probability)}
                      </text>
                      <text x={x} y={y + radius + 17} textAnchor="middle" fontSize="9" fontFamily={THEME_TOKENS.fonts.mono} fill={colors.inkMuted}>
                        {incident.id}
                      </text>
                    </g>
                  );
                })}
              </svg>
              <div className="min-w-0 space-y-3">
                <div className="flex items-start justify-between gap-2 rounded-lg bg-[#FAF6EE] p-2.5">
                  <p className="text-[10px] leading-relaxed text-[#3A2E26]">
                    Conditioned on <span className="font-semibold">{observationLabel}</span> · {collapsed.matchingTrials} of {analysis.annealedSim.trials} worlds match
                  </p>
                  <button
                    type="button"
                    onClick={() => setObserved({})}
                    disabled={observations.length === 0}
                    className="shrink-0 rounded-full px-2 py-1 text-[10px] font-semibold text-[#4F7C82] hover:bg-[#D7E3E5] disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    Clear
                  </button>
                </div>
                <h4 className="font-heading text-xs font-bold text-[#3A2E26]">Strongest pair dependencies</h4>
                {analysis.annealedSim.edges.filter(edge => edge.mutualInformationBits >= 0.005).slice(0, 4).length > 0 ? (
                  <ul className="space-y-2">
                    {analysis.annealedSim.edges
                      .filter(edge => edge.mutualInformationBits >= 0.005)
                      .slice(0, 4)
                      .map(edge => {
                        const a = openIncidents.find(incident => incident.id === edge.a);
                        const b = openIncidents.find(incident => incident.id === edge.b);
                        return (
                          <li key={`${edge.a}-${edge.b}`} className="rounded-lg border border-[#E4D9C5] p-2 text-[10px] leading-relaxed text-[#3A2E26]">
                            If {a ? incidentLabel(a, areas) : edge.a} is reached, {b ? incidentLabel(b, areas) : edge.b} is reached {percentage(edge.pBGivenAReached)} of the time. If missed, only {percentage(edge.pBGivenAMissed)}.
                          </li>
                        );
                      })}
                  </ul>
                ) : (
                  <p className="rounded-lg border border-dashed border-[#D8CCB5] p-3 text-[10px] leading-relaxed text-[#7A6A5A]">
                    No strong pair dependencies (mutual information ≥ 0.005 bit) in these simulated worlds.
                  </p>
                )}
              </div>
            </div>
          </section>

          <section className="min-w-0 rounded-2xl border border-[#E4D9C5] bg-[#FFFDF8] p-4 shadow-[0_1px_2px_rgba(58,46,38,0.06)]">
            <div className="mb-3">
              <h3 className="font-heading text-base font-bold text-[#3A2E26]">Annealed dispatch</h3>
              <p className="mt-1 text-[11px] leading-relaxed text-[#7A6A5A]">Seeded alternatives scored in the same 600 simulated worlds.</p>
            </div>
            <div className="overflow-x-auto rounded-lg border border-[#E4D9C5]">
              <table className="w-full min-w-[510px] text-left text-[10px]">
                <thead className="bg-[#FAF6EE] font-mono text-[#7A6A5A]">
                  <tr>
                    <th className="px-2 py-2 font-semibold">Dispatch</th>
                    <th className="px-2 py-2 font-semibold">Crews</th>
                    <th className="px-2 py-2 font-semibold">Energy</th>
                    <th className="px-2 py-2 font-semibold">Expected reached</th>
                    <th className="px-2 py-2 font-semibold">Worst 5%</th>
                    <th className="px-2 py-2 font-semibold">Spread</th>
                    <th className="px-2 py-2 font-semibold">P(all critical)</th>
                  </tr>
                </thead>
                <tbody>
                  {assignmentRows.map((row, index) => (
                    <tr key={row.label} className={`${index === 2 ? 'font-bold text-[#3A2E26]' : 'text-[#5A4A3A]'} border-t border-[#E4D9C5]`}>
                      <td className="px-2 py-2">{row.label}</td>
                      <td className="px-2 py-2 font-mono">{row.solution.assignments.length}</td>
                      <td className="px-2 py-2 font-mono">{row.solution.energy.toFixed(1)}</td>
                      <td className="px-2 py-2 font-mono">{row.simulation.expectedReached.toFixed(1)}</td>
                      <td className="px-2 py-2 font-mono">{row.simulation.worstCase5pct.toFixed(1)}</td>
                      <td className="px-2 py-2 font-mono">{row.simulation.stdReached.toFixed(1)}</td>
                      <td className="px-2 py-2 font-mono">{percentage(row.simulation.probabilityAllCriticalReached)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="mt-3 rounded-lg bg-[#FAF6EE] p-2.5">
              <p className="mb-1 text-[10px] font-semibold text-[#3A2E26]">Annealing energy trace</p>
              <svg
                viewBox="0 0 300 70"
                role="img"
                aria-label={`Annealing energy trace across ${annealed.steps} steps`}
                className="h-16 w-full"
              >
                <line x1="8" y1="62" x2="292" y2="62" stroke={colors.border} strokeWidth="1" />
                <polyline points={tracePoints} fill="none" stroke={colors.agent} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
              </svg>
              <p className="font-mono text-[9px] text-[#7A6A5A]">
                {annealed.steps} steps, {annealed.tunnelMovesAccepted} of {annealed.tunnelMovesTried} collective moves accepted
              </p>
            </div>

            <div className="mt-3">
              <div className="mb-1 flex flex-wrap items-center justify-between gap-2">
                <h4 className="font-heading text-xs font-bold text-[#3A2E26]">Volunteer → incident</h4>
                <span className="text-[9px] font-semibold text-[#7A6A5A]">for operator review, nothing is sent</span>
              </div>
              <ul className="max-h-36 space-y-1 overflow-y-auto rounded-lg border border-[#E4D9C5] bg-[#FAF6EE] p-2 text-[10px]">
                {annealed.annealed.assignments.map(assignment => {
                  const volunteer = analysis.world.volunteers[assignment.volunteerId];
                  const incident = openIncidents.find(item => item.id === assignment.incidentId);
                  return (
                    <li key={`${assignment.volunteerId}-${assignment.incidentId}`} className="flex justify-between gap-2">
                      <span className="font-semibold text-[#3A2E26]">{volunteer?.name || assignment.volunteerId}</span>
                      <span className="text-right text-[#7A6A5A]">
                        {incident ? incidentLabel(incident, areas) : assignment.incidentId}
                        {annealed.annealed.diversifiedBackupVolunteerIds.includes(assignment.volunteerId)
                          ? ' · backup crew on a different route'
                          : ''}
                      </span>
                    </li>
                  );
                })}
                {annealed.annealed.assignments.length === 0 && (
                  <li className="text-[#7A6A5A]">No crews assigned.</li>
                )}
              </ul>
            </div>
            <p className="mt-3 rounded-lg border-l-2 border-[#4F7C82] bg-[#D7E3E5]/40 p-2.5 text-[10px] leading-relaxed text-[#3A2E26]">
              Gains mostly come from joint multi-crew planning under the 97% floor; annealing only matches greedy on this small scenario. Advisory only; approval still goes through the plan gate.
            </p>
          </section>

          <section className="min-w-0 rounded-2xl border border-[#E4D9C5] bg-[#FFFDF8] p-4 shadow-[0_1px_2px_rgba(58,46,38,0.06)]">
            <div className="mb-3">
              <h3 className="font-heading text-base font-bold text-[#3A2E26]">Interference credibility</h3>
              <p className="mt-1 text-[11px] leading-relaxed text-[#7A6A5A]">A transparent advisory ranking signal from source agreement and contradiction.</p>
            </div>
            <label className="mb-3 block space-y-1 text-[10px] font-semibold text-[#3A2E26]">
              <span>Incident</span>
              <select
                value={selectedIncidentId || ''}
                onChange={event => setInterferenceId(event.currentTarget.value)}
                className="w-full rounded-lg border border-[#E4D9C5] bg-[#FAF6EE] px-2.5 py-2 text-xs text-[#3A2E26] focus:outline-none focus:ring-2 focus:ring-[#4F7C82]"
              >
                {openIncidents.map(incident => (
                  <option key={incident.id} value={incident.id}>
                    {incidentLabel(incident, areas)} · {incident.id}
                  </option>
                ))}
              </select>
            </label>

            <svg
              viewBox={`0 0 360 ${phasorHeight}`}
              role="img"
              aria-label={`Evidence phasors for ${selectedIncident ? incidentLabel(selectedIncident, areas) : 'selected incident'}, with ${interference.terms.length} source groups`}
              className="max-h-64 w-full rounded-xl border border-[#E4D9C5] bg-[#FAF6EE]"
            >
              <defs>
                <marker id="quantum-support-arrow" markerWidth="7" markerHeight="7" refX="6" refY="3.5" orient="auto">
                  <path d="M0,0 L7,3.5 L0,7 z" fill={colors.primary} />
                </marker>
                <marker id="quantum-contradiction-arrow" markerWidth="7" markerHeight="7" refX="6" refY="3.5" orient="auto">
                  <path d="M0,0 L7,3.5 L0,7 z" fill={colors.kill} />
                </marker>
              </defs>
              <line x1="180" y1="12" x2="180" y2={phasorHeight - 8} stroke={colors.border} strokeDasharray="3 3" />
              {interference.terms.map((term, index) => {
                const y = 28 + index * 34;
                const x = 180 + (term.supporting ? 1 : -1) * term.amplitude * phasorScale;
                const color = term.supporting ? colors.primary : colors.kill;
                const groupText = term.reportIds.length > 1
                  ? `${term.reportIds.length} repeats`
                  : '1 report';
                return (
                  <g key={term.groupId}>
                    <line
                      x1="180"
                      y1={y}
                      x2={x}
                      y2={y}
                      stroke={color}
                      strokeWidth="2.5"
                      opacity={0.2 + 0.8 * term.freshness}
                      markerEnd={`url(#quantum-${term.supporting ? 'support' : 'contradiction'}-arrow)`}
                    />
                    <text x="8" y={y - 2} fontSize="9" fontFamily={THEME_TOKENS.fonts.mono} fill={colors.ink}>
                      {term.groupId.slice(0, 22)} · {groupText} · {term.supporting ? 'Support' : 'Contradiction'} · {Math.round(term.freshness * 100)}% fresh
                    </text>
                  </g>
                );
              })}
              <line
                x1="180"
                y1={phasorHeight - 14}
                x2={resultantX}
                y2={phasorHeight - 14}
                stroke={colors.agent}
                strokeWidth="6"
                strokeLinecap="round"
              />
              <text x="8" y={phasorHeight - 10} fontSize="9" fontWeight="700" fill={colors.agent}>Resultant</text>
            </svg>
            <dl className="mt-3 grid grid-cols-2 gap-2 text-[10px]">
              <div className="rounded-lg bg-[#FAF6EE] p-2">
                <dt className="text-[#7A6A5A]">Intensity</dt>
                <dd className="mt-0.5 font-mono font-bold text-[#3A2E26]">{interference.intensity.toFixed(3)}</dd>
              </div>
              <div className="rounded-lg bg-[#FAF6EE] p-2">
                <dt className="text-[#7A6A5A]">Independent-evidence sum</dt>
                <dd className="mt-0.5 font-mono font-bold text-[#3A2E26]">{interference.incoherentSum.toFixed(3)}</dd>
              </div>
              <div className="rounded-lg bg-[#FAF6EE] p-2">
                <dt className="text-[#7A6A5A]">Visibility</dt>
                <dd className="mt-0.5 font-mono font-bold text-[#3A2E26]">{interference.visibility.toFixed(2)}</dd>
              </div>
              <div className="rounded-lg bg-[#FAF6EE] p-2">
                <dt className="text-[#7A6A5A]">Verdict</dt>
                <dd className="mt-0.5 font-mono font-bold capitalize text-[#3A2E26]">{interference.verdict}</dd>
              </div>
              <div className="col-span-2 rounded-lg border border-[#4F7C82]/30 bg-[#D7E3E5]/40 p-2">
                <dt className="text-[#7A6A5A]">Interference credibility</dt>
                <dd className="mt-0.5 font-mono text-base font-bold text-[#4F7C82]">{percentage(interference.credibility)}</dd>
              </div>
            </dl>
            <p className="mt-3 text-[10px] leading-relaxed text-[#7A6A5A]">
              Advisory ranking signal; it does not replace the deterministic score or the human gate.
            </p>
          </section>
        </div>
      )}
      {equity && (
        <section className="rounded-2xl border border-[#E4D9C5] bg-[#FFFDF8] p-4 shadow-[0_1px_2px_rgba(58,46,38,0.06)]">
          <div className="flex flex-wrap items-baseline justify-between gap-2">
            <div>
              <h3 className="font-heading text-base font-bold text-[#3A2E26]">Ward fairness &amp; equity</h3>
              <p className="mt-1 text-[10px] text-[#7A6A5A]">Simulated reach and response times weighted by ward vulnerability.</p>
            </div>
            <span className="font-mono text-xs font-bold text-[#4F7C82]">Unreached-risk Gini {equity.gini.toFixed(3)}</span>
          </div>
          <div className="mt-3 overflow-x-auto">
            <table className="w-full min-w-[560px] text-left text-[10px]">
              <thead className="text-[9px] uppercase tracking-wide text-[#7A6A5A]">
                <tr><th className="pb-2">Ward</th><th className="pb-2">Vulnerability</th><th className="pb-2">Expected response</th><th className="pb-2">Reach probability</th><th className="pb-2">Status</th></tr>
              </thead>
              <tbody>
                {equity.wards.map(ward => (
                  <tr key={ward.areaId} className="border-t border-[#E4D9C5]/70">
                    <td className="py-2 font-semibold text-[#3A2E26]">{ward.name}</td>
                    <td className="py-2 font-mono">{Math.round(ward.vulnerability * 100)}%</td>
                    <td className="py-2 font-mono">{ward.expectedResponseMinutes === null ? 'No crew' : `${ward.expectedResponseMinutes.toFixed(1)} min`}</td>
                    <td className="py-2 font-mono">{percentage(ward.reachProbability)}</td>
                    <td className="py-2">{equity.flaggedWardIds.includes(ward.areaId) ? <span className="font-bold text-[#B0623A]">More than 20 pp below weighted average</span> : <span className="text-[#5F7A61]">Within comparison band</span>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {equity.smallestReassignment && (
            <p className="mt-3 rounded-lg border border-[#4F7C82]/25 bg-[#D7E3E5]/30 p-2 text-[10px] text-[#3A2E26]">
              Smallest suggested reassignment: move one crew ({equity.smallestReassignment.volunteerId}) from {equity.smallestReassignment.fromWard} to {equity.smallestReassignment.toWard}. This is an advisory candidate only; review and approve any plan through the existing gate.
            </p>
          )}
        </section>
      )}
    </div>
  );
};

export default QuantumLab;
